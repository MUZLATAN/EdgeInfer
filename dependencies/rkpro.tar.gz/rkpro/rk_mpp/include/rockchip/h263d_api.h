#ifndef __H263D_API_H__
#define __H263D_API_H__

#include "parser_api.h"

#ifdef  __cplusplus
extern "C" {
#endif

extern const ParserApi api_h263d_parser;

#ifdef  __cplusplus
}
#endif

#endif

